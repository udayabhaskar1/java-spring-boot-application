package sg.nus.iss.JavaCA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaCaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaCaApplication.class, args);
	}

}
