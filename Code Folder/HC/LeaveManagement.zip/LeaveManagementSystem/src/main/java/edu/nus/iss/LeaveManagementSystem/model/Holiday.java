package edu.nus.iss.LeaveManagementSystem.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="holiday")
public class Holiday {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private int id;
	private String holidayName;
	@DateTimeFormat (pattern = "yyyy-MM-dd") //Must use this format, else form cannot save values
	private LocalDate date;
	
	public Holiday() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Holiday(String holidayName, LocalDate date) {
		super();
		this.holidayName = holidayName;
		this.date = date;
	}

	public Holiday(int id, String holidayName, LocalDate date) {
		super();
		this.id = id;
		this.holidayName = holidayName;
		this.date = date;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHolidayName() {
		return holidayName;
	}

	public void setHolidayName(String holidayName) {
		this.holidayName = holidayName;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Holiday other = (Holiday) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
}
