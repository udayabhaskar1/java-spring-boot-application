package edu.nus.iss.LeaveManagementSystem.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {
	@Id
	@Column(name = "employeeid")
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int employeeId;
	//@Column(name = "username")
	private String username;
	//@Column(name = "password")
	private String password;
	//@Column(name = "firstname")
	private String firstName;
	//@Column(name = "lastname")
	private String lastName;
	//@Column(name = "role")
	private String role;
	//@Column(name = "managedBy")
	private int managedBy;
	//@Column(name = "clentitled")
	private int compensationLeaveEntitled;
	//@Column(name = "clbalance")
	private int compensationLeaveBalance;
	//@Column(name = "alentitled")
	private int annualLeaveEntitled;
	//@Column(name = "albalance")
	private int annualLeaveBalance;
	//@Column(name = "mlentitled")
	private int medicalLeaveEntitled;
	//@Column(name = "mlbalance")
	private int medicalLeaveBalance;
	
	@OneToMany(mappedBy="employee", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	private List<LeaveApplication> leaveList = new ArrayList<LeaveApplication>();
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int employeeId) {
		super();
		this.employeeId = employeeId;
	}

	public Employee(int employeeId, String username, String password, String firstName, String lastName, String role,
			int managedBy, int compensationLeaveEntitled, int compensationLeaveBalance, int annualLeaveEntitled,
			int annualLeaveBalance, int medicalLeaveEntitled, int medicalLeaveBalance,
			ArrayList<LeaveApplication> leavelist) {
		super();
		this.employeeId = employeeId;
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.role = role;
		this.managedBy = managedBy;
		this.compensationLeaveEntitled = compensationLeaveEntitled;
		this.compensationLeaveBalance = compensationLeaveBalance;
		this.annualLeaveEntitled = annualLeaveEntitled;
		this.annualLeaveBalance = annualLeaveBalance;
		this.medicalLeaveEntitled = medicalLeaveEntitled;
		this.medicalLeaveBalance = medicalLeaveBalance;
		this.leaveList.addAll(leaveList);
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getManagedBy() {
		return managedBy;
	}

	public void setManagedBy(int managedBy) {
		this.managedBy = managedBy;
	}

	public int getCompensationLeaveEntitled() {
		return compensationLeaveEntitled;
	}

	public void setCompensationLeaveEntitled(int compensationLeaveEntitled) {
		this.compensationLeaveEntitled = compensationLeaveEntitled;
	}

	public int getCompensationLeaveBalance() {
		return compensationLeaveBalance;
	}

	public void setCompensationLeaveBalance(int compensationLeaveBalance) {
		this.compensationLeaveBalance = compensationLeaveBalance;
	}

	public int getAnnualLeaveEntitled() {
		return annualLeaveEntitled;
	}

	public void setAnnualLeaveEntitled(int annualLeaveEntitled) {
		this.annualLeaveEntitled = annualLeaveEntitled;
	}

	public int getAnnualLeaveBalance() {
		return annualLeaveBalance;
	}

	public void setAnnualLeaveBalance(int annualLeaveBalance) {
		this.annualLeaveBalance = annualLeaveBalance;
	}

	public int getMedicalLeaveEntitled() {
		return medicalLeaveEntitled;
	}

	public void setMedicalLeaveEntitled(int medicalLeaveEntitled) {
		this.medicalLeaveEntitled = medicalLeaveEntitled;
	}

	public int getMedicalLeaveBalance() {
		return medicalLeaveBalance;
	}

	public void setMedicalLeaveBalance(int medicalLeaveBalance) {
		this.medicalLeaveBalance = medicalLeaveBalance;
	}

	public ArrayList<LeaveApplication> getLeaveList() {
		return (new ArrayList<LeaveApplication>(leaveList));
	}

	public void setLeavelist(ArrayList<LeaveApplication> leavelist) {
		this.leaveList.addAll(leaveList);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + employeeId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employeeId != other.employeeId)
			return false;
		return true;
	}
	
}
