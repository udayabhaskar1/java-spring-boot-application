package edu.nus.iss.LeaveManagementSystem.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import edu.nus.iss.LeaveManagementSystem.model.Employee;
import edu.nus.iss.LeaveManagementSystem.model.LeaveApplication;

@Repository
public interface LeaveApplicationRepository extends JpaRepository<LeaveApplication, Integer>{
	
	@Query("SELECT la FROM LeaveApplication la WHERE employee = :e ORDER BY la.leaveStartDate DESC")
	ArrayList<LeaveApplication> findLeaveApplicationByEmployee(@Param("e") Employee e);

	@Modifying
	@Transactional
	@Query("UPDATE LeaveApplication la SET leaveStatus = :status WHERE applicationNo = :applicationNo")
	void updateStatus (@Param("status") String status, @Param("applicationNo") int applicationNo);
}
