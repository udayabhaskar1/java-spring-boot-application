package edu.nus.iss.LeaveManagementSystem.model;

import java.time.LocalDate;

//	import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class LeaveApplication {
	
	@Id
	//@Column(name = "applicationno")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int applicationNo;
	//@Column(name = "leavestartdate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")	//Must use this format, else form cannot save values
	private LocalDate leaveStartDate;
	//@Column(name = "leaveenddate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate leaveEndDate;
	//@Column(name = "type")
	private String type;
	//@Column(name = "remark")
	private String remarks;
	//@Column(name = "overseascontactdetails")
	private String overseasContactDetails;
	//@Column(name = "coveringemployeeid")
	private int coveringEmployeeId;
	//@Column(name = "status")
	private String leaveStatus;
	//@Column(name = "mgrcomment")
	private String mgrComment;
	@ManyToOne
	@JoinColumn(name = "employeeid")
	private Employee employee;
	
	public LeaveApplication() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LeaveApplication(int applicationNo) {
		super();
		this.applicationNo = applicationNo;
	}

	public LeaveApplication(int applicationNo, LocalDate leaveStartDate, LocalDate leaveEndDate, String type,
			String remarks, String overseasContactDetails, int coveringEmployeeId, String leaveStatus, String mgrComment,
			Employee employee) {
		super();
		this.applicationNo = applicationNo;
		this.leaveStartDate = leaveStartDate;
		this.leaveEndDate = leaveEndDate;
		this.type = type;
		this.remarks = remarks;
		this.overseasContactDetails = overseasContactDetails;
		this.coveringEmployeeId = coveringEmployeeId;
		this.leaveStatus = leaveStatus;
		this.mgrComment = mgrComment;
		this.employee = employee;
	}

	public int getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(int applicationNo) {
		this.applicationNo = applicationNo;
	}

	public LocalDate getLeaveStartDate() {
		return leaveStartDate;
	}

	public void setLeaveStartDate(LocalDate leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}

	public LocalDate getLeaveEndDate() {
		return leaveEndDate;
	}

	public void setLeaveEndDate(LocalDate leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getOverseasContactDetails() {
		return overseasContactDetails;
	}

	public void setOverseasContactDetails(String overseasContactDetails) {
		this.overseasContactDetails = overseasContactDetails;
	}

	public int getCoveringEmployeeId() {
		return coveringEmployeeId;
	}

	public void setCoveringEmployeeId(int coveringEmployeeId) {
		this.coveringEmployeeId = coveringEmployeeId;
	}

	public String getLeaveStatus() {
		return leaveStatus;
	}

	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}

	public String getMgrComment() {
		return mgrComment;
	}

	public void setMgrComment(String mgrComment) {
		this.mgrComment = mgrComment;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
}
