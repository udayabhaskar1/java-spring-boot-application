package edu.nus.iss.LeaveManagementSystem.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import edu.nus.iss.LeaveManagementSystem.model.LeaveApplication;

public class LeaveApplicationValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		return LeaveApplication.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		LeaveApplication la = (LeaveApplication) arg0;
		if((la.getLeaveStartDate()!=null && la.getLeaveEndDate()!=null)&&(la.getLeaveStartDate().compareTo(la.getLeaveEndDate()) > 0)) {
			arg1.reject("leaveEndDate", "End date should be greater than start date.");
			arg1.rejectValue("leaveEndDate", "error.dates", "End date must be greater than Start date");
		}
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "type", "errors.type", "must be selected");
	}
}
