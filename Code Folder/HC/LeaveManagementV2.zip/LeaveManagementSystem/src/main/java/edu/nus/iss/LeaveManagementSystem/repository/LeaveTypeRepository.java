package edu.nus.iss.LeaveManagementSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.nus.iss.LeaveManagementSystem.model.LeaveType;


@Repository
public interface LeaveTypeRepository extends JpaRepository<LeaveType, Integer> {

}
