package edu.nus.iss.LeaveManagementSystem.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import edu.nus.iss.LeaveManagementSystem.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	
	@Query("SELECT e FROM Employee e WHERE e.employeeId = :employeeId")
	Employee findEmployeeByEmployeeId(@Param("employeeId") int employeeId);
	
	@Modifying
	@Transactional
	@Query("UPDATE Employee e SET annualLeaveBalance =:daysLeft WHERE e.employeeId = :employeeId")
	void setAnnualLeaveBalance(@Param("daysLeft") int daysLeft, @Param("employeeId") int employeeId);
	
	@Modifying
	@Transactional
	@Query("UPDATE Employee e SET compensationLeaveBalance =:daysLeft WHERE e.employeeId = :employeeId")
	void setCompensationLeaveBalance(@Param("daysLeft") int daysLeft, @Param("employeeId") int employeeId);
	
	@Modifying
	@Transactional
	@Query("UPDATE Employee e SET medicalLeaveBalance =:daysLeft WHERE e.employeeId = :employeeId")
	void setMedicalLeaveBalance(@Param("daysLeft") int daysLeft, @Param("employeeId") int employeeId);
}
