package edu.nus.iss.LeaveManagementSystem.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import edu.nus.iss.LeaveManagementSystem.model.Holiday;

public interface HolidayRepository extends JpaRepository<Holiday, Integer>{
	
	@Query("SELECT h FROM Holiday h WHERE h.date =:date")
	Holiday getHolidayByDate(@Param("date") LocalDate date);

}
