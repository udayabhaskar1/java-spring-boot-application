CREATE TABLE `employee` (
`EmployeeId` INT(11) NOT NULL,
`UserName` VARCHAR(45) DEFAULT NULL,
`Password` VARCHAR(45) DEFAULT NULL,
`FirstName` VARCHAR(45) DEFAULT NULL,
`LastName` VARCHAR(45) DEFAULT NULL,  
`Role` VARCHAR(45) DEFAULT NULL,
`CompensationLeave` INT(11) DEFAULT NULL,
`CompensationLeaveBalance` INT(11) DEFAULT NULL,
`AnnualLeaveEntitled` INT(11) DEFAULT NULL,
`AnnualLeaveBalance` INT(11) DEFAULT NULL,
`MedicalLeaveEntitled` INT(11) DEFAULT NULL,
`MedicalLeaveBalance` INT(11) DEFAULT NULL,
PRIMARY KEY (`EmployeeId`);
