package sg.edu.nus.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sg.edu.nus.demo.model.LeaveRecord;

public interface LeaveRecordRepository extends JpaRepository<LeaveRecord, Integer>{

}
