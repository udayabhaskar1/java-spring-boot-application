package sg.edu.nus.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import sg.edu.nus.demo.model.Employee;
import sg.edu.nus.demo.model.LeaveRecord;
import sg.edu.nus.demo.repo.EmployeeRepository;
import sg.edu.nus.demo.repo.LeaveRecordRepository;

@Controller
public class EmployeeController {
	
	private LeaveRecordRepository leaveRepo;
	
	
	@Autowired
	public void setLeaveRepo(LeaveRecordRepository leaveRepo) {
		this.leaveRepo = leaveRepo;
	}

	
	
	@RequestMapping(path = "/leaveform", method = RequestMethod.GET)
    public String showForm(Model model) {
        model.addAttribute("leaveform", new LeaveRecord());
        return "LeaveForm";
    }
	@RequestMapping(path = "/label", method = RequestMethod.POST)
	public String createLabel(LeaveRecord leaveRecord, BindingResult result) {
		if (result.hasErrors()) {
			return "leaveForm";
		}
		leaveRepo.save(leaveRecord);
		return "successpage";		
	}
	
	

}
