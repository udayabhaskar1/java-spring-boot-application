package sg.edu.nus.demo.validator;

public class EmployeeValidator {

}
