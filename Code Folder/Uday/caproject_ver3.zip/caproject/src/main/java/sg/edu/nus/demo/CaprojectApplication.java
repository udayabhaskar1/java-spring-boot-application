package sg.edu.nus.demo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import sg.edu.nus.demo.model.Holiday;
import sg.edu.nus.demo.repo.HolidayRepo;

@SpringBootApplication
public class CaprojectApplication implements CommandLineRunner {
	
	@Autowired
	private HolidayRepo repo;

	public static void main(String[] args) {
		SpringApplication.run(CaprojectApplication.class, args);
	}
	
	public void run(String... args) throws Exception {
		Holiday hol2= new Holiday();
		hol2.setName("ho2");
		hol2.setDate(new Date(119, 7, 19));
		repo.save(hol2);
		
		Holiday hol1= new Holiday();
		hol1.setName("ho1");
		hol1.setDate(new Date(119, 9, 19));
		repo.save(hol1);
		
	}

}
