package sg.edu.nus.demo.validator;

import java.util.ArrayList;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import sg.edu.nus.demo.model.Employee;
import sg.edu.nus.demo.model.Holiday;
import sg.edu.nus.demo.model.LeaveRecord;
import sg.edu.nus.demo.repo.EmployeeRepository;
import sg.edu.nus.demo.repo.HolidayRepo;

public class LeaveRecordValidator implements Validator{
	
	private EmployeeRepository empRepo;
	
	private HolidayRepo holiRepo;
	
	public LeaveRecordValidator(EmployeeRepository emprepo, HolidayRepo holiRepo) {
		this.empRepo = emprepo;
		this.holiRepo = holiRepo;
	}
	
	public boolean supports(Class<?> arg0) {
		return LeaveRecord.class.isAssignableFrom(arg0);
	}

	public void validate(Object arg0, Errors arg1) {
		LeaveRecord leaveRecord = (LeaveRecord) arg0;
		if ((leaveRecord.getLeaveStartDate()!=null && leaveRecord.getLeaveEndDate()!=null)&&(leaveRecord.getLeaveStartDate().compareTo(leaveRecord.getLeaveEndDate()) > 0)) {
			arg1.reject("leaveEndDate", "End date should be greater than start date.");
			arg1.rejectValue("leaveEndDate", "error.dates", "End date must be greater than Start date");
		}
		
		if(Util.isWeedEnd(leaveRecord.getLeaveStartDate())) {
			arg1.reject("leaveStartDate", "must be working day");
			arg1.rejectValue("leaveStartDate", "error.leaveStartDate", "must be working day");
		}
		
		if(Util.isWeedEnd(leaveRecord.getLeaveEndDate())) {
			arg1.reject("leaveEndDate", "must be working day");
			arg1.rejectValue("leaveEndDate", "error.dates", "must be working day");
		}
		
		if(leaveRecord.getType() != null && !leaveRecord.getType().isEmpty() && (leaveRecord.getLeaveStartDate()!=null && leaveRecord.getLeaveEndDate()!=null)&&(leaveRecord.getLeaveStartDate().compareTo(leaveRecord.getLeaveEndDate()) < 0)) {
			Employee emp = empRepo.findById(Util.TEMP_ID).get();
			ArrayList<Holiday> holidays = (ArrayList<Holiday>) holiRepo.findAll();
			int days = Util.calculateDays(leaveRecord.getLeaveStartDate(), leaveRecord.getLeaveEndDate(), holidays);
			if("annualLeave".equalsIgnoreCase(leaveRecord.getType())) {
				if(emp.getAnnualLeaveBalance() < days) {
					arg1.reject("type", "no leaves available");
					arg1.rejectValue("type", "error.type", "no leaves available");
				}
			}
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "type", "errors.type", "must be selected");
	}
	
	

}
