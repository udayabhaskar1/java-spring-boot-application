package sg.edu.nus.demo.controller;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import sg.edu.nus.demo.model.Holiday;
import sg.edu.nus.demo.model.LeaveRecord;
import sg.edu.nus.demo.repo.EmployeeRepository;
import sg.edu.nus.demo.repo.HolidayRepo;
import sg.edu.nus.demo.repo.LeaveRecordRepository;
import sg.edu.nus.demo.validator.LeaveRecordValidator;
import sg.edu.nus.demo.validator.Util;

@Controller
public class EmployeeController {
	
	private LeaveRecordRepository leaveRepo;
	
	private HolidayRepo holiRepo;
	
	private EmployeeRepository empRepo;
	
	@Autowired
	public void setLeaveRepo(LeaveRecordRepository leaveRepo) {
		this.leaveRepo = leaveRepo;
	}
	
	@Autowired
	public void setHoliRepo(HolidayRepo holiRepo) {
		this.holiRepo = holiRepo;
	}

	@Autowired
	public void setEmpRepo(EmployeeRepository empRepo) {
		this.empRepo = empRepo;
	}

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.addValidators(new LeaveRecordValidator(empRepo, holiRepo));
	}

	@RequestMapping(path = "/leaveform", method = RequestMethod.GET)
    public String showForm(Model model) {
        model.addAttribute("leaveform", new LeaveRecord());
        return "LeaveForm";
    }
	
	@RequestMapping(path = "/label", method = RequestMethod.POST)
	public String createLabel(@Valid @ModelAttribute("leaveform") LeaveRecord leaveRecord, BindingResult result) {
		if (result.hasErrors()) {
	        return "LeaveForm";
		}
		
		leaveRecord.setLeaveStatus("APPLIED");
		ArrayList<Holiday> holidays = (ArrayList<Holiday>) holiRepo.findAll();
		int days = Util.calculateDays(leaveRecord.getLeaveStartDate(), leaveRecord.getLeaveEndDate(), holidays);
		leaveRecord.setNoofleaves(days);
		leaveRepo.save(leaveRecord);
        return "LeaveForm";
	}
	
	@RequestMapping(path = "/editlabel/{id}", method = RequestMethod.GET)
    public String showEditForm(Model model, @PathVariable("id") Integer id) {
        model.addAttribute("editform", leaveRepo.findById(id));
        return "navigation";
    }
	
	@RequestMapping(path = "/editlabel", method = RequestMethod.POST, params = "action=create")
	public String createLabel(@Valid @ModelAttribute("editform") LeaveRecord leaveRecord, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "navigation";
		}
		
		ArrayList<Holiday> holidays = (ArrayList<Holiday>) holiRepo.findAll();
		int days = Util.calculateDays(leaveRecord.getLeaveStartDate(), leaveRecord.getLeaveEndDate(), holidays);
		leaveRecord.setNoofleaves(days);
		leaveRecord.setLeaveStatus("UPDATED");
		leaveRepo.save(leaveRecord);
		return "navigation";		
	}
	
	@RequestMapping(path = "/editlabel", method = RequestMethod.POST, params = "action=delete")
    public String deleteForm(Model model, @ModelAttribute("editform") LeaveRecord leaveRecord) {
		if(leaveRecord.getLeaveId() != 0)
			leaveRepo.deleteById(leaveRecord.getLeaveId());
        model.addAttribute("leaveform", new LeaveRecord());
        return "LeaveForm";
    }
	
}
