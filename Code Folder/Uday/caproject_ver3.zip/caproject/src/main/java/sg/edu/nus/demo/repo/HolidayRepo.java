package sg.edu.nus.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sg.edu.nus.demo.model.Holiday;

public interface HolidayRepo extends JpaRepository<Holiday, String> {

}
