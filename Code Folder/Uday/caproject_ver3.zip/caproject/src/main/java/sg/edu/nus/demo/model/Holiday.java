package sg.edu.nus.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="holidays")
public class Holiday {
	@Id
	private String name;
	private Date date;
	public Holiday() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Holiday(String name, Date date) {
		super();
		this.name = name;
		this.date = date;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Holiday [name=" + name + ", date=" + date + "]";
	}
	
	
	
	

}
