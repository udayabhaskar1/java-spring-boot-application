package sg.edu.nus.demo.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class LeaveRecord {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int leaveId;
	private int employeeId;
	@NotNull
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date leaveStartDate;
	@NotNull
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date leaveEndDate;
	@NotEmpty
	private String type;
	@NotEmpty
	private String reason;
	@NotEmpty
	private String employeeAdditionalComments;
	private String overseasContactDetails;
	private boolean overseasTrip;
	private int noofleaves;
	public boolean isOverseasTrip() {
		return overseasTrip;
	}
	public void setOverseasTrip(boolean overseasTrip) {
		this.overseasTrip = overseasTrip;
	}
	private String coveringEmployeeId;
	private String leaveStatus;
	private String managerComments;
	public LeaveRecord() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public LeaveRecord(int leaveId, int employeeId, Date leaveStartDate, Date leaveEndDate, String type, String reason,
			String employeeAdditionalComments, String overseasContactDetails, boolean overseasTrip,
			String coveringEmployeeId, String leaveStatus, String managerComments) {
		super();
		this.leaveId = leaveId;
		this.employeeId = employeeId;
		this.leaveStartDate = leaveStartDate;
		this.leaveEndDate = leaveEndDate;
		this.type = type;
		this.reason = reason;
		this.employeeAdditionalComments = employeeAdditionalComments;
		this.overseasContactDetails = overseasContactDetails;
		this.overseasTrip = overseasTrip;
		this.coveringEmployeeId = coveringEmployeeId;
		this.leaveStatus = leaveStatus;
		this.managerComments = managerComments;
	}
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public Date getLeaveStartDate() {
		return leaveStartDate;
	}
	public void setLeaveStartDate(Date leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}
	public Date getLeaveEndDate() {
		return leaveEndDate;
	}
	public void setLeaveEndDate(Date leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getEmployeeAdditionalComments() {
		return employeeAdditionalComments;
	}
	public void setEmployeeAdditionalComments(String employeeAdditionalComments) {
		this.employeeAdditionalComments = employeeAdditionalComments;
	}
	public String getOverseasContactDetails() {
		return overseasContactDetails;
	}
	public void setOverseasContactDetails(String overseasContactDetails) {
		this.overseasContactDetails = overseasContactDetails;
	}
	public String getCoveringEmployeeId() {
		return coveringEmployeeId;
	}
	public void setCoveringEmployeeId(String coveringEmployeeId) {
		this.coveringEmployeeId = coveringEmployeeId;
	}
	public String getLeaveStatus() {
		return leaveStatus;
	}
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}
	public String getManagerComments() {
		return managerComments;
	}
	public void setManagerComments(String managerComments) {
		this.managerComments = managerComments;
	}
	public int getNoofleaves() {
		return noofleaves;
	}
	public void setNoofleaves(int noofleaves) {
		this.noofleaves = noofleaves;
	}
	@Override
	public String toString() {
		return "LeaveRecord [leaveId=" + leaveId + ", employeeId=" + employeeId + ", leaveStartDate=" + leaveStartDate
				+ ", leaveEndDate=" + leaveEndDate + ", type=" + type + ", reason=" + reason
				+ ", employeeAdditionalComments=" + employeeAdditionalComments + ", overseasContactDetails="
				+ overseasContactDetails + ", overseasTrip=" + overseasTrip + ", coveringEmployeeId="
				+ coveringEmployeeId + ", leaveStatus=" + leaveStatus + ", managerComments=" + managerComments + "]";
	}
		
	
	
	
}
