package sg.edu.nus.demo.validator;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import sg.edu.nus.demo.model.Holiday;

public class Util {
	
	public static int TEMP_ID = 1;

	public static LocalDate parseDate(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int m = cal.get(Calendar.MONTH)+1;
		return LocalDate.of(cal.get(Calendar.YEAR), m, cal.get(Calendar.DAY_OF_MONTH));
	}
	
	public static boolean isWeedEnd(Date date) {
		LocalDate ld = parseDate(date);
		switch(ld.getDayOfWeek()) {
		case SATURDAY:
			return true;
		case SUNDAY:
			return true;
			default:
				return false;
		}
	}

	public static int calculateDays(Date startDate, Date endDate, List<Holiday> holidays) {
		LocalDate sd = Util.parseDate(startDate);
		LocalDate ed = Util.parseDate(endDate).plusDays(1);
		int days = (int) ChronoUnit.DAYS.between(sd, ed);
		
		if(days <= 14) {
			days = excludeHolidays(sd, ed, holidays);
		}
		return days;
	}
	
	private static int excludeHolidays(LocalDate sd, LocalDate ed, List<Holiday> holidays) {
		ArrayList<LocalDate> dates = new ArrayList<LocalDate>();
		for(;sd.isBefore(ed);sd=sd.plusDays(1)) {
			switch(sd.getDayOfWeek()) {
			case SATURDAY:
				break;
			case SUNDAY:
				break;
				default:
					dates.add(sd);
					break;
			}
		}
		
		ArrayList<LocalDate> dts = new ArrayList<LocalDate>();
		if(!holidays.isEmpty()) {
			for(Holiday day : holidays) {
				dts.add(Util.parseDate(day.getDate()));
			}
		}
		
		if(!dts.isEmpty())
			dates.removeAll(dts);
		
		return dates.size();
	}
	

}
