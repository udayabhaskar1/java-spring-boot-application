package edu.nus.iss.LeaveManagementSystem.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

//	import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.nus.iss.LeaveManagementSystem.model.Employee;
import edu.nus.iss.LeaveManagementSystem.model.Holiday;
import edu.nus.iss.LeaveManagementSystem.model.LeaveApplication;
import edu.nus.iss.LeaveManagementSystem.repository.EmployeeRepository;
import edu.nus.iss.LeaveManagementSystem.repository.HolidayRepository;
import edu.nus.iss.LeaveManagementSystem.repository.LeaveApplicationRepository;

@Service
public class LeaveService implements LeaveServiceIntf{
	
	private LeaveApplicationRepository laRepo;
	private EmployeeRepository eRepo;
	private HolidayRepository hRepo;
//	@Resource
	@Autowired
	public void setLaRepo(LeaveApplicationRepository laRepo)
	{
		this.laRepo = laRepo;
	}
	
//	@Resource
	@Autowired
	public void setERepo(EmployeeRepository eRepo)
	{
		this.eRepo = eRepo;
	}
	
//	@Resource
	@Autowired
	public void setHRepo(HolidayRepository hRepo)
	{
		this.hRepo = hRepo;
	}

	@Override
	public ArrayList<LeaveApplication> findLeaveApplicationByEmployee(Employee e) {
		return laRepo.findLeaveApplicationByEmployee(e);
	}
	
	@Override
	public ArrayList<LeaveApplication> findLeaveApplicationByEmployeeId(int id) {
		Employee e = eRepo.findEmployeeByEmployeeId(id);
		ArrayList<LeaveApplication> laList = laRepo.findLeaveApplicationByEmployee(e);
		return laList;
	}
	
	@Override
	public boolean notEnoughLeave(int daysApplied, int daysLeft) {
		if (daysApplied > daysLeft)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@Override
	public LeaveApplication findLeaveByApplicationNo(int id)
	{
		return laRepo.getOne(id);
	}
	
	@Override
	public String getStatus(int applicationNo) {
		return laRepo.getOne(applicationNo).getLeaveStatus();
	}

	@Override
	public void updateStatus(String status, int applicationNo) {
		laRepo.updateStatus(status, applicationNo);
		return;
	}
	
	@Override
	public int calculateLeave(LocalDate sd, LocalDate ed, LeaveApplication la) {
		int days = (int) ChronoUnit.DAYS.between(sd, ed);
		if(days <= 14 && !(la.getType().contains("medical"))) {
			days = excludeHolidays(sd, ed);
		}
		return days;
	}
	
	private int excludeHolidays(LocalDate sd, LocalDate ed) {
		ArrayList<LocalDate> dates = new ArrayList<LocalDate>();
		for(;sd.isBefore(ed);sd=sd.plusDays(1)) {
			switch(sd.getDayOfWeek()) {
			case SATURDAY:
				break;
			case SUNDAY:
				break;
			default:
				dates.add(sd);
				break;
			}
		}
		ArrayList<Holiday> holidays = (ArrayList<Holiday>) hRepo.findAll();
		ArrayList<LocalDate> dts = new ArrayList<LocalDate>();
		if(!holidays.isEmpty()) {
			for(Holiday day : holidays) {
				dts.add(day.getDate());
			}
		}
		if(dts.isEmpty())
			dates.removeAll(dts);
		
		return dates.size();
	}
	
	@Override
	public ArrayList<String> validateLeave(LeaveApplication la) {
		ArrayList<String> errorList = new ArrayList<String>();
		if ((la.getLeaveStartDate().getDayOfWeek().getValue() == 6) || (la.getLeaveStartDate().getDayOfWeek().getValue() == 7))
		{
			errorList.add("Start Date cannot be on a weekend");
		}
		if (hRepo.getHolidayByDate(la.getLeaveStartDate()) != null)
		{
			errorList.add("Start Date cannot be on a public holiday");
		}
		if (la.getLeaveStartDate().isAfter(la.getLeaveEndDate()))
		{
			errorList.add("Start date cannot be before end date");
		}
		if ((la.getType().contains("Overseas")) && (la.getOverseasContactDetails() == ""))
		{
			errorList.add("Please provide an overseas contact detail");
		}
		return errorList;
	}
	
	@Override
	public void saveLeave(LeaveApplication la) {
		laRepo.save(la);
	}
	
	@Override
	public Holiday getHolidayByDate(LocalDate date) {
		return hRepo.getHolidayByDate(date);
	}
	
	@Override
	public Employee findEmployeeByEmployeeId(int employeeId) {
		return eRepo.findEmployeeByEmployeeId(employeeId);
	}
	
	@Override
	public Employee findEmployeeByApplicationNo(int applicationNo) {
		return laRepo.getOne(applicationNo).getEmployee();
	}

	@Override
	public String getFullName(int id) {
		String name = eRepo.findEmployeeByEmployeeId(id).getFirstName() + " " + eRepo.findEmployeeByEmployeeId(id).getLastName();
		return name;
	}

	@Override
	public boolean isProfessional(int id) {
		boolean check = false;
		if (eRepo.findEmployeeByEmployeeId(id).getRole().contains("Professional"))
		{
			check = true;
		}
		return check;
	}
	
	@Override
	public int findLeaveBalanceByEmployeeId(String type, int id) {
		int days = 0;
		if (type.contains("annual"))
		{
			days = eRepo.getOne(id).getAnnualLeaveBalance();
		}
		else if (type.contains("compensation"))
		{
			days = eRepo.getOne(id).getCompensationLeaveBalance();
		}
		else if (type.contains("medical"))
		{
			days = eRepo.getOne(id).getMedicalLeaveBalance();
		}
		return days;
		
	}
	
	@Override
	public void setLeaveBalance(String type,int id, int days) {
		if (type.contains("annual"))
		{
			eRepo.setAnnualLeaveBalance(days, id);
		}
		else if (type.contains("compensation"))
		{
			eRepo.setCompensationLeaveBalance(days, id);
		}
		else if (type.contains("medical"))
		{
			eRepo.setMedicalLeaveBalance(days, id);
		}
		
	}
	
	//Codes Below are for testing purposes only
	
	public void addManyEmployee(ArrayList<Employee> eList)
	{
		eRepo.saveAll(eList);
		return;
	}
	
	public void addManyLeaveApplications(ArrayList<LeaveApplication> laList, int empId)
	{
		Employee e = eRepo.findEmployeeByEmployeeId(empId);
		e.setLeavelist(laList);	//May not be necessary
		for (LeaveApplication la: laList)	//May not be necessary
		{
			la.setEmployee(e);
		}
		laRepo.saveAll(laList);
	}
	
	public void addHolidays(ArrayList<Holiday> hList)
	{
		hRepo.saveAll(hList);
	}
	
}
