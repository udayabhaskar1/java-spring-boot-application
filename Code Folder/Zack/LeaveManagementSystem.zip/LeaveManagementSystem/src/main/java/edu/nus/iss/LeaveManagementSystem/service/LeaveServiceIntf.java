package edu.nus.iss.LeaveManagementSystem.service;

import java.time.LocalDate;
import java.util.ArrayList;

import edu.nus.iss.LeaveManagementSystem.model.Employee;
import edu.nus.iss.LeaveManagementSystem.model.Holiday;
import edu.nus.iss.LeaveManagementSystem.model.LeaveApplication;

public interface LeaveServiceIntf {
	
	ArrayList<LeaveApplication> findLeaveApplicationByEmployee(Employee e);
	
	ArrayList<LeaveApplication> findLeaveApplicationByEmployeeId(int id);
	
	LeaveApplication findLeaveByApplicationNo(int id);
	
	String getStatus(int applicationNo);
	
	void updateStatus(String status, int applicationNo);
	
	int calculateLeave(LocalDate sd, LocalDate ed, LeaveApplication la);
	
	ArrayList<String> validateLeave(LeaveApplication la);
	
	boolean notEnoughLeave(int daysApplied, int daysLeft);
	
	void saveLeave(LeaveApplication la);
	
	//This one is for the validation of public holidays, as leave cannot start on public holidays
	
	Holiday getHolidayByDate(LocalDate date);
	
	//This side downwards are employee based queries
	Employee findEmployeeByEmployeeId(int employeeId);
	
	Employee findEmployeeByApplicationNo(int applicationNo);
	
	String getFullName(int id);
	
	boolean isProfessional(int id);
	
	int findLeaveBalanceByEmployeeId(String type, int id);
	
	void setLeaveBalance(String type, int id, int days);
}
