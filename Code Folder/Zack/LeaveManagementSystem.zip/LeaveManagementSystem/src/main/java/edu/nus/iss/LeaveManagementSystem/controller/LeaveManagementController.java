package edu.nus.iss.LeaveManagementSystem.controller;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.WebDataBinder;
//import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.nus.iss.LeaveManagementSystem.model.Employee;
import edu.nus.iss.LeaveManagementSystem.model.Holiday;
import edu.nus.iss.LeaveManagementSystem.model.LeaveApplication;
import edu.nus.iss.LeaveManagementSystem.service.LeaveService;
//import edu.nus.iss.LeaveManagementSystem.validators.LeaveApplicationValidator;

@Controller
public class LeaveManagementController {
	
	@Autowired
	private LeaveService ls;
	
//	@InitBinder
//	protected void initBinder(WebDataBinder binder) {
//		binder.addValidators(new LeaveApplicationValidator());
//	}	Commented off because it was interfering with a leave history
//	If want to turn this on, please remember to un-comment the necessary imports
	
	@RequestMapping(path = "/")
	public String index(Model model)
	{
		return "default";
	}
	
	@RequestMapping(path = "/{id}")
	public String welcome(Model model, @PathVariable(value = "id") int id)
	{
		String name = ls.getFullName(id);
		model.addAttribute("employeeName", name);
		boolean check = ls.isProfessional(id);
		if(check == true)
		{
			return "bosswelcome";
		}
		else
		{
			return "employeewelcome";
		}
	}
	
	@RequestMapping(path = "/leavehistory/{id}")
	public String viewHistory(Model model, @PathVariable(value = "id") int id)
	{
		ArrayList<LeaveApplication> laList = ls.findLeaveApplicationByEmployeeId(id);
		model.addAttribute("laList", laList);
		LocalDate current = LocalDate.now();
		model.addAttribute("current", current);
		model.addAttribute("id", id);
		return "leavehistory";
	}
	
	@RequestMapping(path = "/leavehistory/viewapplication/{id}")
	public String viewDetails(Model model, @PathVariable(value = "id") int id)
	{
		LeaveApplication la = ls.findLeaveByApplicationNo(id);
		model.addAttribute("LeaveApplication", la);
		LocalDate current = LocalDate.now();
		model.addAttribute("current", current);
		return "leavedetails";
	}
	
	@RequestMapping(path = "/applyforleave/{id}")
	public String applyLeave(Model model, @PathVariable(value = "id") int id)
	{
		Employee e = ls.findEmployeeByEmployeeId(id);
		LeaveApplication la = new LeaveApplication();
		la.setEmployee(e);
		model.addAttribute("LeaveApplication", la);
		ArrayList<String> errorList = new ArrayList<String>();
		model.addAttribute("errorList", errorList);
		return "leaveform";
	}
	
	@RequestMapping(path = "leavedetails/editleave/{id}")
	public String editLeave(Model model, @PathVariable(value = "id") int id)
	{
		LeaveApplication la = ls.findLeaveByApplicationNo(id);
		model.addAttribute("LeaveApplication", la);
		ArrayList<String> errorList = new ArrayList<String>();
		model.addAttribute("errorList", errorList);
		return "leaveform";
	}
	
	@RequestMapping(path = "/validateApplication/{id}", method = RequestMethod.POST)
	public String validateLeave(@Valid @ModelAttribute("LeaveApplication") LeaveApplication la, Model model, @PathVariable(value = "id") int id)
	{
		la.setEmployee(ls.findEmployeeByEmployeeId(id));
		ArrayList<String> errorList = ls.validateLeave(la);
		if (!errorList.isEmpty())
		{
			model.addAttribute("errorList", errorList);
			model.addAttribute("LeaveApplication", la);
			return "leaveform";
		}
		//Deduct Leave from system. Can only do this after ensuring inputs are validated via validateLeave method
		int days = ls.calculateLeave(la.getLeaveStartDate(), la.getLeaveEndDate(), la);
		if (ls.notEnoughLeave(days, ls.findLeaveBalanceByEmployeeId(la.getType(), la.getEmployee().getEmployeeId())))
		{
			errorList.add("Sorry, you do not have enough Leave to apply");
			model.addAttribute("errorList", errorList);
			model.addAttribute("LeaveApplication", la);
			return "leaveform";
		}
		ls.setLeaveBalance(la.getType(), la.getEmployee().getEmployeeId(), (ls.findLeaveBalanceByEmployeeId(la.getType(), la.getEmployee().getEmployeeId())) - days);
		//Save Leave to system
		ls.saveLeave(la);
		ls.updateStatus("Applied", la.getApplicationNo());
		//Notify Boss of leave (Not implemented here)
		return "redirect:/leavehistory/" + id;
	}
	
	@RequestMapping(path = "/leavehistory/deleteapplication/{applicationno}" , method = RequestMethod.GET)
	public String deleteLeave(@PathVariable (value ="applicationno") int applicationNo)
	{
		String status = ls.getStatus(applicationNo);
		if (status.contains("Applied"))
		{
			ls.updateStatus("Deleted", applicationNo);
		}
		else if (status.contains("Approved"))
		{
			ls.updateStatus("Cancelled", applicationNo);
		}
		LeaveApplication la = ls.findLeaveByApplicationNo(applicationNo);
		ls.setLeaveBalance(la.getType(), la.getEmployee().getEmployeeId(), ls.calculateLeave(la.getLeaveStartDate(), la.getLeaveEndDate(), la) + ls.findLeaveBalanceByEmployeeId(la.getType(), la.getEmployee().getEmployeeId()));
		//The method above sets the leave balance to the correct amount after leave is cancelled or deleted.
		//This is important, may want to note when manager rejects leave.
		//Note that leave is deducted once leave is applied.
		return ("redirect:/leavehistory/" + ls.findEmployeeByApplicationNo(applicationNo).getEmployeeId());
	}
	
	//Note: Need to implement a way to recover leave if applied and the boss has not approved, 
	//since the employee cannot delete the leave after start date has passed
	
	//Paths below are for testing purposes only
	
	@RequestMapping(path = "/invoketestdata")
	public String Tester(Model model)
	{
		ArrayList<Employee> eList = new ArrayList<Employee>();
		ArrayList<LeaveApplication> aList = new ArrayList<LeaveApplication>();
		Employee e = new Employee((int)1, "JamesTay", "password", "James", "Tay", "Professional", 1, 0, 0, 18, 14, 60, 50, aList);
		eList.add(e);
		e = new Employee((int)2, "AudreyTan", "password", "Audrey", "Tan", "Staff", 1, 8, 4, 14, 10, 60, 60, aList);
		eList.add(e);
		e = new Employee((int)3, "SayoriRen", "password", "Sayori", "Ren", "Staff", 1, 4, 0, 14, 7, 60, 30, aList);
		eList.add(e);
		e = new Employee((int)4, "MonikaUeda", "password", "Monika", "Ueda", "Professional", 4, 0, 0, 18, 18, 60, 60, aList);
		eList.add(e);
		e = new Employee((int)5, "NatsukiChan", "password", "Natsuki", "Chan", "Staff", 4, 0, 0, 7, 7, 60, 60, aList);
		eList.add(e);
		ls.addManyEmployee(eList);
		return "redirect:/";
	}

	@RequestMapping(path = "/invoketestdata2")
	public String Tester2(Model model)
	{
		ArrayList<LeaveApplication> laList = new ArrayList<LeaveApplication>();
		LeaveApplication a = new LeaveApplication((int)5, LocalDate.now().plusDays(27), LocalDate.now().plusDays(33), "Vacation, Overseas", "Time to relax", "Call me XYXY", 4, "Applied", "", null);
		laList.add(a);
		a = new LeaveApplication((int)2, LocalDate.now().minusDays(20), LocalDate.now().plusDays(18), "Vacation, Local", "Have Errands to run", "", 4, "Approved", "", null);
		laList.add(a);
		a = new LeaveApplication((int)1, LocalDate.now().minusDays(33), LocalDate.now().minusDays(27), "Medical", "Illness", "", 4, "Approved", "Get Well Soon", null);
		laList.add(a);
		ls.addManyLeaveApplications(laList, 1);	//Update James Tay's Leave set
		laList = new ArrayList<LeaveApplication>();
		a = new LeaveApplication((int)4, LocalDate.now().plusDays(16), LocalDate.now().plusDays(18), "Vacation, Local", "House got leak", "", 2, "Approved", "", null);
		laList.add(a);
		a = new LeaveApplication((int)3, LocalDate.now().minusDays(9), LocalDate.now().minusDays(6), "Medical", "Bad Cough", "", 2, "Applied", "", null);
		laList.add(a);
		ls.addManyLeaveApplications(laList, 3); //Update Sayori Ren's Leave set
		return "redirect:/";
	}
	
	@RequestMapping(path = "/invoketestdata3")
	public String Tester3(Model model)
	{
		ArrayList<Holiday> hList = new ArrayList<Holiday>();
		Holiday h = new Holiday("New Year's Day", LocalDate.of(2019, 1, 1));
		hList.add(h);
		h = new Holiday("Chinese New Year", LocalDate.of(2019, 2, 5));
		hList.add(h);
		h = new Holiday("Chinese New Year2", LocalDate.of(2019, 2, 6));
		hList.add(h);
		h = new Holiday("Good Friday", LocalDate.of(2019, 4, 19));
		hList.add(h);
		h = new Holiday("Labour Day", LocalDate.of(2019, 5, 1));
		hList.add(h);
		h = new Holiday("Vesak Day", LocalDate.of(2019, 5, 19));
		hList.add(h);
		h = new Holiday("Vesak Day2", LocalDate.of(2019, 5, 20));
		hList.add(h);
		h = new Holiday("Hari Raya Puasa", LocalDate.of(2019, 6, 5));
		hList.add(h);
		h = new Holiday("National Day", LocalDate.of(2019, 8, 9));
		hList.add(h);
		h = new Holiday("Hari Raya Haji", LocalDate.of(2019, 8, 11));
		hList.add(h);
		h = new Holiday("Hari Raya Haji2", LocalDate.of(2019, 5, 12));
		hList.add(h);
		h = new Holiday("Deepavali", LocalDate.of(2019, 10, 27));
		hList.add(h);
		h = new Holiday("Deepavali2", LocalDate.of(2019, 10, 28));
		hList.add(h);
		h = new Holiday("Christmas", LocalDate.of(2019, 12, 25));
		hList.add(h);
		ls.addHolidays(hList);
		return "redirect:/";
	}
}
