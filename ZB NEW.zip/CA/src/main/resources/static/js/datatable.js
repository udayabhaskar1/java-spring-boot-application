$(document).ready( function () {
	 var table = $('#Records').DataTable({
			"sAjaxSource": "/Recordss",
			"sAjaxDataProp": "",
			"order": [[ 0, "asc" ]],
			"aoColumns": [
			      { "mData": "id"},
			      { "mData": "name" },
		          { "mData": "start_date" },
				  { "mData": "end_date" },
				  { "mData": "type" },
				  { "mData": "reason" },
				  { "mData": "remark" },
				  { "mData": "cover_employeeid" },
				  { "mData": "contact" },
				  { "mData": "status" },
				  { "mData": "mar_comment" }
			]
	 })
});