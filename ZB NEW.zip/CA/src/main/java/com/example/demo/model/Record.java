package com.example.demo.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="leave_record")
public class Record {
	@Id
	
	private int id;
	private Date start_date;
	private Date end_date;
	private String type;
	private String reason;
	private String remark;
	@OneToOne
    @JoinColumn(name="employee_id")
    public Employee employee_id;
	private int cover_employeeid;

	public Employee getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(Employee employee_id) {
		this.employee_id = employee_id;
	}
	public Record() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Record(int id, Date start_date, Date end_date, String type, String reason, String remark,
			int cover_employeeid, String contact, String status, String mgr_comment) {
		super();
		this.id = id;
		this.start_date = start_date;
		this.end_date = end_date;
		this.type = type;
		this.reason = reason;
		this.remark = remark;
		this.cover_employeeid = cover_employeeid;
		this.contact = contact;
		this.status = status;
		this.mgr_comment = mgr_comment;
	}
	@Override
	public String toString() {
		return "Record [id=" + id + ", start_date=" + start_date + ", end_date=" + end_date + ", type=" + type
				+ ", reason=" + reason + ", remark=" + remark + ", cover_employeeid=" + cover_employeeid + ", contact="
				+ contact + ", status=" + status + ", mgr_comment=" + mgr_comment + "]";
	}
	private String contact;
	private String status;
	private String mgr_comment;
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public int getCover_employeeid() {
		return cover_employeeid;
	}
	public void setCover_employeeid(int cover_employeeid) {
		this.cover_employeeid = cover_employeeid;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMgr_comment() {
		return mgr_comment;
	}
	public void setMgr_comment(String mgr_comment) {
		this.mgr_comment = mgr_comment;
	}
	public int getId() {
		return id;
	}


}
