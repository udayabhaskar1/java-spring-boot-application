package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repo.RecordRepository;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Record;
import com.example.demo.repo.RecordRepository;
import com.example.demo.repo.EmployeeRepository;
import com.example.demo.service.RecordService;

@RestController
public class ManagerRestController {
		private RecordRepository RecordRepository;

		@Autowired
		public void setRecordRepository(RecordRepository RecordRepository) {
			this.RecordRepository = RecordRepository;
		}
		
		@RequestMapping(path="/Recordss", method=RequestMethod.GET)
		public ArrayList<Record> getAllRecords() {
			return (ArrayList<Record>) RecordRepository.findAll();
		}


}
