package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Record;
import com.example.demo.repo.RecordRepository;
import com.example.demo.repo.EmployeeRepository;
import com.example.demo.service.RecordService;

@Controller
public class ManagerController {

	private RecordRepository RecordRepository;
	private EmployeeRepository EmployeeRepository;

	
	@Autowired
	public void setRecordRepository(RecordRepository RecordRepository) {
		this.RecordRepository = RecordRepository;
	}
	
	@Autowired
	public void setEmployeeRepository(EmployeeRepository EmployeeRepository) {
		this.EmployeeRepository = EmployeeRepository;
	}

	@RequestMapping(path = "/")
	public String index() {
		return "index";
	}

	@RequestMapping(path = "/Records/add", method = RequestMethod.GET)
	public String createRecord(Model model) {
		model.addAttribute("Record", new Record());
		return "edit";
	}

	@RequestMapping(path = "Records", method = RequestMethod.POST)
	public String saveRecord(@Valid Record SelectedRecord, Model model) {
		RecordRepository.save(SelectedRecord);
		return "Records";
	}


	@RequestMapping(path = "/Records", method = RequestMethod.GET)
	public String getAllRecords(Model model) {
		model.addAttribute("Records", RecordRepository.findAll());
		return "Records";
	}
	
	@RequestMapping(path = "/SubRecords", method = RequestMethod.GET)
	public String getAllSubRecords(Model model) {
		model.addAttribute("SubRecords", RecordRepository.findSubRecordsByStatus("pending",1));
		return "SubRecords";
	}

	@RequestMapping(path = "/Records/view/{id}", method = RequestMethod.GET)
	public String getEmployeeRecords(Model model,@PathVariable(value = "id") int id) {
		Record r = RecordRepository.findById(id).orElse(null);
		ArrayList<Record> rr= RecordRepository.findByTime(r.getStart_date(), r.getEnd_date());
		model.addAttribute("Records", rr);
		model.addAttribute("SelectedRecord", r);
		return "ViewEmployeeRecord";
	}
	
	@RequestMapping(path = "/CompletedRecords", method = RequestMethod.GET)
	public String getAllPendingRecords(Model model) {
		model.addAttribute("Records", RecordRepository.findByStatus("completed"));
		return "CompletedRecords";
	}

	@RequestMapping(path = "/Records/delete/{id}", method = RequestMethod.GET)
	public String deleteRecord(@PathVariable(name = "id") int id) {
		RecordRepository.delete(RecordRepository.findById(id).orElse(null));
		return "redirect:/Records";
	}
}
