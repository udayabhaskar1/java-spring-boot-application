package com.example.demo.repo;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Employee;
import com.example.demo.model.Record;

import antlr.collections.List;


@Repository
public interface RecordRepository extends JpaRepository<Record, Integer> {
	

	
	@Query("select r from Record r,Employee e where r.status = ?1 and e.employee_id=r.employee_id and e.report_to = ?2")
	ArrayList<Record> findSubRecordsByStatus(String status,int id);
		
	@Query("select r from Record r where r.status = ?1")
	ArrayList<Record> findByStatus(String status);
	
	@Query("select r from Record r where r.start_date >= ?1 and r.end_date <= ?2")
	ArrayList<Record> findByTime(Date startdate,Date enddate);


}

