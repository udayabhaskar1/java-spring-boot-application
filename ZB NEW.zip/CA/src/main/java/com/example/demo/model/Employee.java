package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="employee")
public class Employee {
	@Id
	private int employee_id;
	private String username;
	private String password;
	private String firstname; 
	private String lastname;
	private String role;
	private int annual_leave_entitled;
	private double annual_leave_bal;
	private int medical_leave_entitled;
	private double medical_leave_bal;
	private int report_to;

	public int getemployee_id() {
		return employee_id;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employee [employee_id=" + employee_id + ", username=" + username + ", password=" + password + ", firstname=" + firstname
				+ ", lastname=" + lastname + ", role=" + role + ", annual_leave_entitled=" + annual_leave_entitled
				+ ", annual_leave_bal=" + annual_leave_bal + ", medical_leave_entitled=" + medical_leave_entitled
				+ ", medical_leave_bal=" + medical_leave_bal + ", report_to=" + report_to + "]";
	}

	public void setemployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getAnnual_leave_entitled() {
		return annual_leave_entitled;
	}
	public void setAnnual_leave_entitled(int annual_leave_entitled) {
		this.annual_leave_entitled = annual_leave_entitled;
	}
	public double getAnnual_leave_bal() {
		return annual_leave_bal;
	}
	public void setAnnual_leave_bal(double annual_leave_bal) {
		this.annual_leave_bal = annual_leave_bal;
	}
	public int getMedical_leave_entitled() {
		return medical_leave_entitled;
	}
	public void setMedical_leave_entitled(int medical_leave_entitled) {
		this.medical_leave_entitled = medical_leave_entitled;
	}
	public double getMedical_leave_bal() {
		return medical_leave_bal;
	}
	public void setMedical_leave_bal(double medical_leave_bal) {
		this.medical_leave_bal = medical_leave_bal;
	}
	public int getReport_to() {
		return report_to;
	}
	public void setReport_to(int report_to) {
		this.report_to = report_to;
	}
}
