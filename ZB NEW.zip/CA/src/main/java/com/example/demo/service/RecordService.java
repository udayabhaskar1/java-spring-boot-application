package com.example.demo.service;
import java.util.ArrayList;
import com.example.demo.model.Record;

public interface RecordService {
	ArrayList<String> findAllRecords();

}
