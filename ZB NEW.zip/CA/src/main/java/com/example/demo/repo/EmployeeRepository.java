package com.example.demo.repo;

import java.sql.Date;
import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Employee;
import com.example.demo.model.Record;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
		
	@Query("select e from Employee e")
	ArrayList<Employee> findAll();
	

}

